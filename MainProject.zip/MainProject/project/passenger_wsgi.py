import mySite.wsgi
application= mySite.wsgi.application
