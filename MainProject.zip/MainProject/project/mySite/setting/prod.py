from mySite.settings import *
DEBUG = False

ALLOWED_HOSTS = ['mrblank.ir','www.mrblank.ir']


STATIC_URL = '/static/'

MEDIA_URL = '/media/'

STATICFILES_DIRS = [
    BASE_DIR / "statics",
]
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'mrblankd_MyDB',
        'USER': 'mrblankd_ahmadreza',
        'PASSWORD': '*.^nutw~itLE',
        'HOST': 'localhost',  # Use 'localhost' or the MySQL server hostname
        'PORT': '3306',           # Leave empty to use the default MySQL port (3306)
    }
}
MEDIA_ROOT = '/home/mrblankd/public_html/media'
STATIC_ROOT =  '/home/mrblankd/public_html/static'
COMPRESS_ENABLED = True
COMPRESS_ROOT = STATIC_ROOT ##django compressor
COMPRESS_OFFLINE = True
SITE_ID=3
# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'django-insecure-i$6&ttaqdd5o6&vja+tk9$2bm3raro3(l*n7(7$2)o!p62_zq*'
SECURE_HSTS_SECONDS = 31536000  # 1 year
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True
SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')
SECURE_SSL_REDIRECT = True