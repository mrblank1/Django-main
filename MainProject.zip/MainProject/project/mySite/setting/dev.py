from mySite.settings import *
DEBUG = True

ALLOWED_HOSTS = ['mrblank.ir','www.mrblank.ir']


STATIC_URL = '/static/'

MEDIA_URL = '/media/'

STATICFILES_DIRS = [
    BASE_DIR / "statics",
]
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'mrblankd_MyDB',
        'USER': 'mrblankd_ahmadreza',
        'PASSWORD': '*.^nutw~itLE',
        'HOST': 'localhost',  # Use 'localhost' or the MySQL server hostname
        'PORT': '3306',           # Leave empty to use the default MySQL port (3306)
    }
}
MEDIA_ROOT = '/home/mrblankd/public_html/media'
STATIC_ROOT =  '/home/mrblankd/public_html/static'
COMPRESS_ENABLED = True
COMPRESS_ROOT = STATIC_ROOT ##django compressor
COMPRESS_OFFLINE = True